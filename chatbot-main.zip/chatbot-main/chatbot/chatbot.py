# Python Modules
import random
import json
import pickle
import numpy as np
import nltk
from keras.models import load_model
# Find the Word Lemma , reducing same meaning words into singke word
from nltk.stem import WordNetLemmatizer

# for text-to-speech, speech reconig, for Computer Telephone Integration
# Chatbot can be used for voice integration with users calling to hotline
import speech_recognition
from gtts import gTTS

# for data
import os
import datetime
import time


lemmatizer = WordNetLemmatizer()
intents = json.loads(open("training.json").read())
words   = pickle.load(open('words.pkl', 'rb'))
classes = pickle.load(open('classes.pkl', 'rb'))

# using predefined chatbotmodel for now
model = load_model('chatbotmodel.h5')

def clean_up_sentences(input):
    
	words = nltk.word_tokenize(input)
	words = [lemmatizer.lemmatize(word)
					for word in words]
	return words

def bagw(input):
	sentence_words = clean_up_sentences(input)
	bag = [0]*len(words)
	for w in sentence_words:
		for i, word in enumerate(words):
			if word == w:
				bag[i] = 1
	return np.array(bag)

def predict_class(input):
	bow = bagw(input)
	#print(bow)    
	res = model.predict(np.array([bow]))[0]
	ERROR_THRESHOLD = 0.25
	results = [[i, r] for i, r in enumerate(res)
			if r > ERROR_THRESHOLD]
	results.sort(key=lambda x: x[1], reverse=True)
	return_list = []
	for r in results:
		return_list.append({'intent': classes[r[0]],
							'probability': str(r[1])})
		return return_list

def get_response(intents_list, intents_json):
	tag = intents_list[0]['intent']
	list_of_intents = intents_json['intents']
	result = ""
	for i in list_of_intents:
		if i['tag'] == tag:
			result = random.choice(i['responses'])
			break
	return result

def google_speak(input,language):
    speaker = gTTS(text=input, lang=language, slow=False)
    speaker.save("res.mp3")
    statbuf = os.stat("res.mp3")
    mbytes = statbuf.st_size / 1024
    duration = mbytes / 200
    os.system('start res.mp3')  #if you are using mac->afplay or else for windows->start
	# os.system("close res.mp3")
    time.sleep(int(50*duration))
    os.remove("res.mp3")
    return

print("Chatbot is up!")
# rule based first question and response
print("Please enter you name.")
message = input("")
res = "Nice to meet you " + message + ". I am your health assistant, here to support your personal well-being. I am a friendly interactive tool"
print(res)
# google_speak(res,"en")
# It can support multi Languages
# google_speak(res,"ja")

while True:
    message = input("")
    # find the anwser tag for the input sentance
    ints = predict_class(message)
    # Get the response from the pre-defined list
    res = get_response(ints, intents)
    print(res)
    # Optional Google Speech
    google_speak(res,"en")
    # print(ints[0])
    if res == "Bye":
        exit()
	