This is the partial Python Code for our chatbot.

I am still working on the training.json, the questions and answers for training our chatbot

Code is based on the human language processing and tensorflow 2. I am usng the pretrained chatbotmodel. I will try to see if we have enough time to build our own training model.

It also support speech recognition and text to speech.